package com.railways;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
